#ifndef __IDRIS_TERM_H
#define __IDRIS_TERM_H

void idris2_setupTerm();
int idris2_getTermCols();
int idris2_getTermLines();

#endif
